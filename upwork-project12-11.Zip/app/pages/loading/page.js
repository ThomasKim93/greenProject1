import Loading from '../../comp/Loading'
import React from 'react'

function page() {
  return (
    <>
      <Loading/>
    </>
  )
}

export default page
