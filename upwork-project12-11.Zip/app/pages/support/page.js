import Support from '../../comp/Support'
import React from 'react'

function page() {
  return (
    <>
      <Support/>
    </>
  )
}

export default page
