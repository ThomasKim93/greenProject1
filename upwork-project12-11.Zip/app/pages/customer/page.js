import Customer from '../../comp/Customer'
import React from 'react'

function page() {
  return (
    <>
      <Customer/>
    </>
  )
}

export default page
