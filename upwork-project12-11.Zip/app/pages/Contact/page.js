import React from 'react'
import Contactus from '../../comp/Contactus'
function page() {
  return (
    <div>
        <Contactus/>
    </div>
  )
}

export default page