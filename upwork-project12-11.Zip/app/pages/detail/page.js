import Detail from '../../comp/Detail'
import React from 'react'


function page() {
  return (
    <>
    <Detail/>
    </>
  )
}

export default page
