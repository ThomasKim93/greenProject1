import React from 'react'
import Error from '../../comp/Error'
function page() {
  return (
    <>
      <Error/>
    </>
  )
}

export default page
