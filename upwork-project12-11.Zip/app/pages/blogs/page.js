import Blogs from '../../comp/Blogs'
import React from 'react'

function page() {
  return (
    <>
      <Blogs/>
    </>
  )
}

export default page
