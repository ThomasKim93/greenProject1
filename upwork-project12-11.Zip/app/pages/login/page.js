import Login from '../../comp/Login'
import React from 'react'

function page() {
  return (
    <>
    <Login/>
    </>
  )
}

export default page
