import Aboutus from '../../comp/Aboutus'
import React from 'react'

function page() {
  return (
    <>
      <Aboutus/>
    </>
  )
}

export default page
