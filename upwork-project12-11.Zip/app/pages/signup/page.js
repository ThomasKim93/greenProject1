import Signup from '../../comp/Signup'
import React from 'react'

function page() {
  return (
    <>
    <Signup/>
    </>
  )
}

export default Signup