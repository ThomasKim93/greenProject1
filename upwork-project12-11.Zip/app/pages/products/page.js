import React from 'react'
import Products from '../../comp/Products'
function page() {
  return (
    <div>
        <Products/>
    </div>
  )
}

export default page