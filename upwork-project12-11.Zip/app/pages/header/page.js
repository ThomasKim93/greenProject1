import React from 'react'
import Header from '../../comp/Header'

function page() {
  return (
    <div>
        <Header/>
    </div>
  )
}

export default page