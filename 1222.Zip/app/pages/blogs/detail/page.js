import React from 'react'
import style from '../detail/detail.module.scss';
import Detail from '../../../component/Detail';

function page() {
   
  return (
    <>
    
     <Detail/>
    </>
  )
}

export default page
