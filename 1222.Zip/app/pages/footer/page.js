import Footer from '../../component/Footer'
import React from 'react'

function page() {
  return (
    <div><Footer/></div>
  )
}

export default page