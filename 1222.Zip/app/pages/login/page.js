import Login from '../../component/Login'
import React from 'react'

function page() {
  return (
    <>
    <Login/>
    </>
  )
}

export default page
