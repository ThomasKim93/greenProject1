import Customer from '../../component/Customer'
import React from 'react'

function page() {
  return (
    <>
      <Customer/>
    </>
  )
}

export default page
