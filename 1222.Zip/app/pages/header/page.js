import React from 'react'
import Header from '../../component/Header'

function page() {
  return (
    <div>
        <Header/>
    </div>
  )
}

export default page