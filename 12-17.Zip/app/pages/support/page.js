import Support from '../../component/Support'
import React from 'react'

function page() {
  return (
    <>
      <Support/>
    </>
  )
}

export default page
