import Solution from '../../component/Solution'
import React from 'react'

function page() {
  return (
    <>
      <Solution/>
    </>
  )
}

export default page
