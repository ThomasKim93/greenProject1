import Blogs from '../../component/Blogs'
import React from 'react'

function page() {
  return (
    <>
      <Blogs/>
    </>
  )
}

export default page
