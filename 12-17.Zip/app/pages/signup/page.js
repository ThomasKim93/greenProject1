import Signup from '../../component/Signup'
import React from 'react'

function page() {
  return (
    <>
    <Signup/>
    </>
  )
}

export default Signup