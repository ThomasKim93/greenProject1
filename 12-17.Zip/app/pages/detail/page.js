import Detail from '../../component/Detail'
import React from 'react'


function page() {
  return (
    <>
    <Detail/>
    </>
  )
}

export default page
