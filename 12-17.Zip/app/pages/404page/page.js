import React from 'react'
import Error from '../../component/Error'
function page() {
  return (
    <>
      <Error/>
    </>
  )
}

export default page
