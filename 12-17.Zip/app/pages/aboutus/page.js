import Aboutus from '../../component/Aboutus'
import React from 'react'

function page() {
  return (
    <>
      <Aboutus/>
    </>
  )
}

export default page
