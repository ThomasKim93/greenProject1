import Loading from '../../component/Loading'
import React from 'react'

function page() {
  return (
    <>
      <Loading/>
    </>
  )
}

export default page
