import React from 'react'
import Contactus from '../../component/Contactus'
function page() {
  return (
    <div>
        <Contactus/>
    </div>
  )
}

export default page