import React from 'react'
import support from '../pages/support/support.module.scss';


function Support() {
  return (
    <>
      <h1>Support</h1>
    </>
  )
}

export default Support
